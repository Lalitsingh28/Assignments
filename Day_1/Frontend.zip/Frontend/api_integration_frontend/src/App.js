import ContentGenerator from './compnent/ContentGenerator';

function App() {
  return (
    <div className="App">
      <ContentGenerator></ContentGenerator>
    </div>
  );
}

export default App;
