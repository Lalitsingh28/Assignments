import React, { useState } from 'react';
import axios from 'axios';

function ContentGenerator() {
  const [keyword, setKeyword] = useState('');
  const [generatedContent, setGeneratedContent] = useState('');
  const [error, setError] = useState('');

  const handleGenerateContent = async () => {
    try {
      const response = await axios.get(`http://localhost:8888/content/word?keyword=${keyword}`);
      setGeneratedContent(response.data);
      setError('');
    } catch (err) {
      setError('Error generating content. Please try again later.');
    }
  };

  return (
    <div>
      <h1>Content Generator</h1>
      <div>
        <label htmlFor="keyword">Enter a Keyword:</label>
        <input
          type="text"
          id="keyword"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
        />
      </div>
      <button onClick={handleGenerateContent}>Generate</button>
      {generatedContent && (
        <div>
          <h2>Generated Content:</h2>
          <p>{generatedContent}</p>
        </div>
      )}
      {error && <p>{error}</p>}
    </div>
  );
}

export default ContentGenerator;